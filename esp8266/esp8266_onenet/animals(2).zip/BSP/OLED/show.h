#ifndef _OLED_H_
#define _OLED_H_

#include "headfile.h"


void show_str(int food_data1,int food_data2,uint32_t water_data,uint32_t temperature_data);
#endif