#ifndef __HEADFILE_H__
#define __HEADFILE_H__

#include "main.h"
#include "dht11.h"
#include "oled.h"
#include "HX711.h"
#include "Onenet.h"
#include "usart.h"
#endif